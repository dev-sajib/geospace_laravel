<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_details', function (Blueprint $table) {
            $table->text('joining_reason')->nullable()->after('bio');
            $table->string('english_proficiency', 50)->nullable()->after('joining_reason');
            $table->integer('years_of_experience')->nullable()->after('english_proficiency');
            $table->string('primary_job_interest', 100)->nullable()->after('years_of_experience');
            $table->text('experience_industries')->nullable()->after('primary_job_interest');
            $table->string('previous_company', 255)->nullable()->after('experience_industries');
            $table->text('skills_summary')->nullable()->after('previous_company');
            $table->enum('job_type', ['Full-time', 'Part-time', 'Contract', 'Freelance'])->nullable()->after('skills_summary');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_details', function (Blueprint $table) {
            $table->dropColumn([
                'joining_reason',
                'english_proficiency',
                'years_of_experience',
                'primary_job_interest',
                'experience_industries',
                'previous_company',
                'skills_summary',
                'job_type'
            ]);
        });
    }
};
