<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserDetail;
use App\Models\CompanyDetail;
use App\Models\Notification;
use App\Models\DropdownValue;
use App\Models\MenuItem;
use App\Models\VisitorLog;
use App\Helpers\AesEncryptionHelper;
use App\Helpers\MessageHelper;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Models\FileUpload;

class CommonController extends Controller
{
    /**
     * User login
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function login(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'Email' => 'required|email',
                'Password' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            $email = $request->input('Email');
            $password = $request->input('Password');

            $user = User::with('role')
                        ->where('email', $email)
                        ->first();

            if (!$user) {
                return response()->json(
                    MessageHelper::unauthorized('Invalid credentials'),
                    401
                );
            }

            // Check if user is active
            if (!$user->is_active) {
                return response()->json([
                    'StatusCode' => 403,
                    'Message' => 'Your account is not active. Please check your email for activation notification.',
                    'Success' => false
                ], 403);
            }

            // Check if user is verified (for freelancers)
            if ($user->role_id == 2 && $user->verification_status == 'pending') {
                return response()->json([
                    'StatusCode' => 403,
                    'Message' => 'Your account is pending verification. Please check your email for updates.',
                    'Success' => false
                ], 403);
            }

            // Check password
            if (str_starts_with($user->password_hash, '$2b$') || str_starts_with($user->password_hash, '$2y$')) {
                if (!password_verify($password, $user->password_hash)) {
                    return response()->json(
                        MessageHelper::unauthorized('Invalid credentials'),
                        401
                    );
                }
            } else {
                $decryptedPassword = AesEncryptionHelper::decrypt($user->password_hash);
                if ($password !== $decryptedPassword) {
                    return response()->json(
                        MessageHelper::unauthorized('Invalid credentials'),
                        401
                    );
                }
            }

            // Generate JWT token
            $token = JWTAuth::fromUser($user);

            // Update last login
            $user->last_login = now();
            $user->save();

            return response()->json(
                MessageHelper::success('Login successful', [
                    'Token' => $token,
                    'UserDetails' => [
                        'UserId' => $user->user_id,
                        'Email' => $user->email,
                        'RoleId' => $user->role_id,
                        'RoleName' => $user->role->role_name,
                        'IsVerified' => $user->is_verified,
                        'VerificationStatus' => $user->verification_status
                    ]
                ])
            );

        } catch (\Exception $e) {
            Log::error('Login error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Login failed: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Freelancer Signup - Step 1 (Basic Info Only, No User Creation Yet)
     * FIXED: Validate email uniqueness but don't create user yet
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function signUpFreelancer(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'UserPosition' => 'required|string|max:100',
                'UserName' => 'required|string|max:255',
                'Email' => 'required|email|unique:users,email',
                'PasswordHash' => 'required|string|min:6',
                'RoleId' => 'required|integer|exists:roles,role_id'
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            // FIXED: Don't create user yet, just validate email uniqueness and return data
            // Store signup data temporarily in session or cache if needed
            // For now, just return success with the data
            
            return response()->json(
                MessageHelper::success('Email validated successfully. Please complete your profile.', [
                    'Email' => $request->input('Email'),
                    'UserPosition' => $request->input('UserPosition'),
                    'UserName' => $request->input('UserName'),
                    'RoleId' => $request->input('RoleId'),
                    'PasswordHash' => $request->input('PasswordHash'),
                    'AuthProvider' => $request->input('AuthProvider')
                ])
            );

        } catch (\Exception $e) {
            Log::error('Freelancer signup validation error: ' . $e->getMessage());

            if (str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), 'unique')) {
                return response()->json(
                    MessageHelper::error('Email already exists'),
                    409
                );
            }

            return response()->json(
                MessageHelper::error('Registration failed: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Freelancer Signup - Step 2 (Complete Profile and Create User)
     * FIXED: This is where we actually create the user account
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function signUpFreelancerDetails(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                // User basic info from step 1
                'Email' => 'required|email|unique:users,email',
                'PasswordHash' => 'required|string|min:6',
                'UserPosition' => 'required|string|max:100',
                'RoleId' => 'required|integer|exists:roles,role_id',
                
                // User details from step 2
                'FirstName' => 'required|string|max:100',
                'LastName' => 'required|string|max:100',
                'ProfilePhoto' => 'required|string',
                'ResumeOrCV' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            DB::beginTransaction();

            try {
                // Encrypt password
                $encryptedPassword = AesEncryptionHelper::encrypt($request->input('PasswordHash'));

                // FIXED: Create user only after all details are provided
                $user = User::create([
                    'email' => $request->input('Email'),
                    'password_hash' => $encryptedPassword,
                    'role_id' => $request->input('RoleId'),
                    'user_position' => $request->input('UserPosition'),
                    'auth_provider' => $request->input('AuthProvider', 'Manual'),
                    'is_active' => true,
                    'is_verified' => false,
                    'verification_status' => 'pending'
                ]);

                // Create user details
                UserDetail::create([
                    'user_id' => $user->user_id,
                    'first_name' => $request->input('FirstName'),
                    'last_name' => $request->input('LastName'),
                    'phone' => $request->input('CellNumber'),
                    'country' => $request->input('Country'),
                    'city' => $request->input('City'),
                    'address' => $request->input('Address'),
                    'postal_code' => $request->input('PostalCode'),
                    'linkedin_url' => $request->input('LinkedInProfileLink'),
                    'profile_image' => $request->input('ProfilePhoto'),
                    'resume_or_cv' => $request->input('ResumeOrCV'),
                    'hourly_rate' => $request->input('PreferredHourlyRate') ? (float)$request->input('PreferredHourlyRate') : null
                ]);

                DB::commit();

                // Send welcome email with verification pending message
                try {
                    Mail::send('emails.verification_pending', ['user' => $user], function ($message) use ($user) {
                        $message->to($user->email)
                                ->subject('Welcome to GeoSpace - Verification Pending');
                    });
                } catch (\Exception $mailException) {
                    Log::error('Failed to send welcome email: ' . $mailException->getMessage());
                    // Don't fail the request if email fails
                }

                return response()->json(
                    MessageHelper::success('Registration successful! One of our agents will contact you soon.', [
                        'UserId' => (int)$user->user_id
                    ])
                );

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Freelancer registration error: ' . $e->getMessage());

            if (str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), 'unique')) {
                return response()->json(
                    MessageHelper::error('Email already exists'),
                    409
                );
            }

            return response()->json(
                MessageHelper::error('Failed to complete registration: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Company Signup
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function signUpCompanyDetails(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'Email' => 'required|email|unique:users,email',
                'PasswordHash' => 'required|string|min:6',
                'RoleId' => 'required|integer|exists:roles,role_id',
                'CompanyName' => 'required|string|max:255',
                'CompanyType' => 'required|string|max:100'
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            DB::beginTransaction();

            try {
                // Encrypt password
                $encryptedPassword = AesEncryptionHelper::encrypt($request->input('PasswordHash'));

                // Create user
                $user = User::create([
                    'email' => $request->input('Email'),
                    'password_hash' => $encryptedPassword,
                    'role_id' => $request->input('RoleId'),
                    'user_position' => 'Company',
                    'auth_provider' => $request->input('AuthProvider', 'Manual'),
                    'is_active' => true,
                    'is_verified' => false,
                    'verification_status' => 'pending'
                ]);

                // Create company details
                CompanyDetail::create([
                    'user_id' => $user->user_id,
                    'company_name' => $request->input('CompanyName'),
                    'company_type' => $request->input('CompanyType'),
                    'industry' => $request->input('Industry'),
                    'website' => $request->input('Website'),
                    'phone' => $request->input('Phone'),
                    'address' => $request->input('Address'),
                    'city' => $request->input('City'),
                    'country' => $request->input('Country'),
                    'postal_code' => $request->input('PostalCode'),
                    'logo' => $request->input('Logo')
                ]);

                DB::commit();

                // Send welcome email
                try {
                    Mail::send('emails.verification_pending', ['user' => $user], function ($message) use ($user) {
                        $message->to($user->email)
                                ->subject('Welcome to GeoSpace - Verification Pending');
                    });
                } catch (\Exception $mailException) {
                    Log::error('Failed to send welcome email: ' . $mailException->getMessage());
                }

                return response()->json(
                    MessageHelper::success('Company registered successfully! One of our agents will contact you soon.', [
                        'UserId' => (int)$user->user_id
                    ])
                );

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $e) {
            Log::error('Company registration error: ' . $e->getMessage());

            if (str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), 'unique')) {
                return response()->json(
                    MessageHelper::error('Email already exists'),
                    409
                );
            }

            return response()->json(
                MessageHelper::error('Failed to complete registration: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * File Upload
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function uploadFile(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'file' => 'required|file|max:10240' // 10MB max
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            if ($request->hasFile('file')) {
                $file = $request->file('file');
                $originalName = $file->getClientOriginalName();
                $extension = $file->getClientOriginalExtension();
                $fileName = time() . '_' . uniqid() . '.' . $extension;
                
                // Store in public/uploads
                $path = $file->storeAs('uploads', $fileName, 'public');

                return response()->json([
                    'success' => true,
                    'message' => 'File uploaded successfully',
                    'filePath' => 'storage/' . $path,
                    'fileName' => $originalName
                ]);
            }

            return response()->json(
                MessageHelper::error('No file uploaded'),
                400
            );

        } catch (\Exception $e) {
            Log::error('File upload error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('File upload failed: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Get authenticated user details
     *
     * @return JsonResponse
     */
    public function me(): JsonResponse
    {
        try {
            $user = auth()->user();
            
            if (!$user) {
                return response()->json(
                    MessageHelper::unauthorized('User not authenticated'),
                    401
                );
            }

            $user->load(['role', 'userDetails', 'companyDetails']);

            return response()->json(
                MessageHelper::success('User details retrieved successfully', [
                    'UserId' => $user->user_id,
                    'Email' => $user->email,
                    'RoleId' => $user->role_id,
                    'RoleName' => $user->role->role_name ?? null,
                    'UserPosition' => $user->user_position,
                    'IsVerified' => $user->is_verified,
                    'IsActive' => $user->is_active,
                    'VerificationStatus' => $user->verification_status,
                    'UserDetails' => $user->userDetails,
                    'CompanyDetails' => $user->companyDetails
                ])
            );

        } catch (\Exception $e) {
            Log::error('Get user error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Failed to retrieve user details'),
                500
            );
        }
    }

    /**
     * Logout
     *
     * @return JsonResponse
     */
    public function logout(): JsonResponse
    {
        try {
            JWTAuth::invalidate(JWTAuth::getToken());
            
            return response()->json(
                MessageHelper::success('Logged out successfully')
            );

        } catch (\Exception $e) {
            Log::error('Logout error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Logout failed'),
                500
            );
        }
    }

    /**
     * Get menus by role ID
     *
     * @return JsonResponse
     */
    // public function getMenusByRoleId(): JsonResponse
    // {
    //     try {
    //         $user = auth()->user();
            
    //         if (!$user) {
    //             return response()->json(
    //                 MessageHelper::unauthorized('User not authenticated'),
    //                 401
    //             );
    //         }

    //         $menus = MenuItem::whereHas('roles', function ($query) use ($user) {
    //             $query->where('role_id', $user->role_id);
    //         })
    //         ->where('is_active', true)
    //         ->whereNull('parent_menu_id')
    //         ->with(['children' => function ($query) use ($user) {
    //             $query->whereHas('roles', function ($q) use ($user) {
    //                 $q->where('role_id', $user->role_id);
    //             })
    //             ->where('is_active', true)
    //             ->orderBy('sort_order');
    //         }])
    //         ->orderBy('sort_order')
    //         ->get();

    //         return response()->json($menus);

    //     } catch (\Exception $e) {
    //         Log::error('Get menus error: ' . $e->getMessage());
    //         return response()->json(
    //             MessageHelper::error('Failed to retrieve menus'),
    //             500
    //         );
    //     }
    // }
        /**
     * Get menus by role ID
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getMenusByRoleId(Request $request): JsonResponse
    {
        try {
            $roleId = $request->query('roleId');
            \Log::info('getMenusByRoleId Request', ['$roleId'=>$roleId]);

            if (!$roleId) {
                return response()->json(
                    MessageHelper::error('RoleId is required'),
                    400
                );
            }

            // Enable query logging for this specific query
            DB::enableQueryLog();

            // Get all menus with permissions for the role
            $allMenus = DB::table('menu_items as m')
                ->join('role_menu_access as rp', 'm.menu_id', '=', 'rp.menu_id')
                ->where('rp.role_id', $roleId)
                ->where('rp.can_view', true)
                ->where('m.is_active', true)
                ->select('m.*', 'rp.can_edit', 'rp.can_delete')
                ->orderBy('m.sort_order')
                ->get();

            // Separate parent and child menus
            $parentMenus = $allMenus->whereNull('parent_menu_id');
            $childMenus = $allMenus->whereNotNull('parent_menu_id');

            // Build the hierarchical structure
            $structuredMenus = [];
            foreach ($parentMenus as $parent) {
                $parentArray = (array) $parent;

                // Get children for this parent
                $children = $childMenus->where('parent_menu_id', $parent->menu_id)->values();
                $parentArray['sub_links'] = $children->toArray();

                $structuredMenus[] = $parentArray;
            }

            return response()->json($structuredMenus);

        } catch (\Exception $e) {
            return response()->json(
                MessageHelper::error('An error occurred: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Get notifications
     *
     * @return JsonResponse
     */
    public function notifications(): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $notifications = Notification::where('user_id', $user->user_id)
                ->orderBy('created_at', 'desc')
                ->limit(50)
                ->get();

            return response()->json($notifications);

        } catch (\Exception $e) {
            Log::error('Get notifications error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Failed to retrieve notifications'),
                500
            );
        }
    }

    /**
     * Update notification
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function updateNotification(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'NotificationId' => 'required|integer|exists:notifications,notification_id'
            ]);

            if ($validator->fails()) {
                return response()->json(
                    MessageHelper::validationError($validator->errors()->toArray()),
                    422
                );
            }

            $notification = Notification::find($request->input('NotificationId'));
            $notification->is_read = true;
            $notification->save();

            return response()->json(
                MessageHelper::success('Notification updated successfully')
            );

        } catch (\Exception $e) {
            Log::error('Update notification error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Failed to update notification'),
                500
            );
        }
    }

    /**
     * Get dropdown data by category
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function dropdownDataByCategory(Request $request): JsonResponse
    {
        try {
            $category = $request->query('CategoryCode');

            if (!$category) {
                return response()->json(
                    MessageHelper::error('CategoryCode is required'),
                    400
                );
            }

            $dropdownData = DB::table('dropdown_values as dv')
                ->join('dropdown_categories as dc', 'dv.category_id', '=', 'dc.category_id')
                ->where('dc.category_code', $category)
                ->where('dv.is_active', true)
                ->select('dv.*')
                ->orderBy('dv.sort_order')
                ->get();

            if ($dropdownData->count() > 0) {
                return response()->json($dropdownData);
            } else {
                return response()->json(
                    MessageHelper::notFound('No data found for category: ' . $category),
                    404
                );
            }

        } catch (\Exception $e) {
            return response()->json(
                MessageHelper::error('An error occurred: ' . $e->getMessage()),
                500
            );
        }
    }

    /**
     * Log visitor
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function logVisitor(Request $request): JsonResponse
    {
        try {
            VisitorLog::create([
                'role_id' => $request->input('RoleId'),
                'device_info' => $request->input('DeviceInfo'),
                'ip_address' => $request->ip(),
                'visited_at' => now()
            ]);

            return response()->json(
                MessageHelper::success('Visitor logged successfully')
            );

        } catch (\Exception $e) {
            Log::error('Log visitor error: ' . $e->getMessage());
            return response()->json(
                MessageHelper::error('Failed to log visitor'),
                500
            );
        }
    }

    /**
     * LinkedIn OAuth Callback
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function linkedInCallback(Request $request): JsonResponse
    {
        // Implement LinkedIn OAuth logic here
        return response()->json(
            MessageHelper::success('LinkedIn authentication successful')
        );
    }
}